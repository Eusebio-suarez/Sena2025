class Animal {
    // Atributos privados
    #nombre
    #especie
    #edad
  
    constructor(nombre, especie, edad) {
      this.#nombre = nombre
      this.#especie = especie
      this.#edad = edad
    }
  
    get nombre() {
      return this.#nombre
    }
 
    set nombre(nuevoNombre) {
      this.#nombre = nuevoNombre
      console.log(`Ahora el animal se llama ${this.#nombre}`);
    }

    get edad() {
      return this.#edad;
    }
  
    toString() {
      console.log(`Nombre: ${this.#nombre}, Especie: ${this.#especie}, Edad: ${this.#edad} años`)
    }
  
    emitirSonido() {
      console.log(`${this.#nombre} hace un sonido.`);
    }
  
    cumplirAnios() {
      this.#edad++;
      console.log(`${this.#nombre} ahora tiene ${this.#edad} años.`)
    }

    comer(){
        console.log(`${this.#nombre} esta comiendo`)
    }
}
  
  const miAnimal = new Animal("Luna", "Perro", 4);
  miAnimal.toString();          // Nombre: Luna, Especie: Perro, Edad: 4 años
  miAnimal.emitirSonido();         // Luna hace un sonido.
  miAnimal.cumplirAnios();         // Luna ahora tiene 5 años.
  miAnimal.nombre = "Max";         // Ahora el animal se llama Max (usando setter)
  console.log(miAnimal.nombre);    // Max (usando getter)
  console.log(miAnimal.edad);      // 5 (usando getter)
  
  // clase  que extiende
  class Gato extends Animal {
    // Atributo adicional para la clase Gato
    #tipoDeVivienda;
  
    constructor(nombre, edad, tipoDeVivienda) {
      super(nombre, "Gato", edad) 
      this.#tipoDeVivienda = tipoDeVivienda 
    }
  
    maullar() {
      console.log(`${this.nombre} dice: Miau!`)
    }
  
    get tipoDeVivienda() {
      return this.#tipoDeVivienda
    }
  
    set tipoDeVivienda(tipo) {
      this.#tipoDeVivienda = tipo
      console.log(`${this.nombre} ahora vive en un lugar de tipo: ${this.#tipoDeVivienda}`)
    }
  
    // Sobreescribir el método toString
    toString() {
      super.toString() // Llamamos al toString de la clase Animal
      console.log(`Este gato vive en un lugar de tipo: ${this.#tipoDeVivienda}`)
    }
  }
  
  const miGato = new Gato("luna", 2, "Interior")
  miGato.toString()// Nombre: luna, Especie: Gato, Edad: 2 años. Este gato vive en un lugar de tipo: Interior
  miGato.maullar()// luna dice: Miau!
  miGato.cumplirAnios()// luna ahora tiene 3 años.
  miGato.tipoDeVivienda = "Exterior"// luna ahora vive en un lugar de tipo: Exterior
  console.log(miGato.tipoDeVivienda)// Exterior