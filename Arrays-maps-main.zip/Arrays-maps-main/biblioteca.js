//Suponga que está desarrollando un sistema para una biblioteca que necesita filtrar una
//lista de números que representan los códigos de libros disponibles. La lista está almacenada
//en un arreglo llamado codigosLibros y el objetivo es crear una función que devuelva solo
//los códigos mayores a 50 utilizando una función flecha y el método filter. El arreglo inicial
//es: [10, 25, 60, 45, 80, 15, 70].


// solucion en array
//codigo de libros en array
const codigosLibrosArray = [10, 25, 60, 45, 80, 15, 70];

//filtrar los codigos mayores a 50
const codigosMayoresA50Array = codigosLibrosArray.filter(codigo => codigo > 50);

console.log(codigosMayoresA50Array.forEach((codigo)=> console.log(codigo)));

// solucion en mapa
//codigo de libros en mapa
const codigosLibrosMap = new Map([
    [1, 10],
    [2, 25],
    [3, 60],
    [4, 45],
    [5, 80],
    [6, 15],
    [7, 70]
]);

//filtrar los codigos mayores a 50
const codigosMayoresA50Map = [...codigosLibrosMap.entries()].filter(([key, value]) => value > 50);
console.log(codigosMayoresA50Map.forEach(([key,value])=> console.log(value)));