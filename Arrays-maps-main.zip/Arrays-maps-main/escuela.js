// 7. Suponga que estás desarrollando un sistema para una escuela que necesita organizar los
// puntajes de los estudiantes en un examen. Tienes un arreglo de puntajes [85, 92, 78, 95, 88]
// y deseas crear un Map donde las claves sean los índices del arreglo (0, 1, 2, etc.) y los
// valores sean los puntajes correspondientes. Luego, quieres agregar un nuevo puntaje 90 al
// Map con la clave correspondiente al siguiente índice disponible (en este caso, 5).

// puntajes
let puntajes = [85, 92, 78, 95, 88];

// Map para almacenar los puntajes
let puntajesMap = new Map([]);

// Agregar los puntajes del arreglo al Map
for (let i = 0; i < puntajes.length; i++) {
    puntajesMap.set(i, puntajes[i]);
}

// Agregar un nuevo puntaje al Map
puntajesMap.set(5,90)

// Imprimir el Map
console.log(puntajesMap);