// 8. Suponga que estás desarrollando un sistema para una empresa que gestiona proyectos.
// Tienes un arreglo de Map donde cada Map representa los detalles de un proyecto, con
// claves como "nombre" y "presupuesto". El arreglo inicial contiene dos proyectos: [{nombre
// => "Proyecto A", presupuesto => 5000}, {nombre => "Proyecto B", presupuesto =>
// 8000}]. Necesitas agregar un nuevo proyecto al arreglo con los datos {nombre =>
// "Proyecto C", presupuesto => 6000}.

// arreglo de mapas con los proyectos
let proyectos = [
    new Map([["nombre", "Proyecto A"], ["presupuesto", 5000]]),
    new Map([["nombre", "Proyecto B"], ["presupuesto", 8000]])
]

//añadir proyecto
proyectos.push(new Map([["nombre", "Proyecto C"], ["presupuesto",6000]]))